		<div class="footer">
        
        	<ul>
            	<li><a href="../index.php">Home</a></li>
                <li><a href="../bio.php">Bio</a></li>
                <li><a href="../portfolio.php">Portfolio</a></li>
                <li><a href="index.php">Blog</a></li>
                <li><a href="../contact.php" style="border-right: none;">Contact</a></li>
            </ul>
            
            <div class="copy">
            	&copy;&nbsp; 
				<script type="text/javascript">
                    var theDate=new Date();
                    document.write(theDate.getFullYear());
                </script>
                &nbsp;Ian Coulton
                <br />
                Portfolio powered by <a href="http://flickr.com" target="_blank">Flickr</a>, Blog powered by <a href="http://wordpress.com" target="_blank">Wordpress</a>
            </div>
        
        </div>
    
    </div>
    
    <!-- end footer -->
	
    <?php wp_footer(); ?>
   
</body>
</html>