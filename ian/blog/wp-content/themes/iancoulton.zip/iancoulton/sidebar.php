<div class="categories">
    <h3>Categories</h3>
    <ul id="categories">
        <?php wp_list_categories('show_count=0&title_li=&hide_empty=0&exclude=1'); ?>
    </ul>
</div>